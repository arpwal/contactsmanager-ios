//
//  ContactsManager.h
//  ContactsManager
//
//  Created by Arpit Agarwal on 3/5/25.
//

#import <Foundation/Foundation.h>

//! Project version number for ContactsManager.
FOUNDATION_EXPORT double ContactsManagerVersionNumber;

//! Project version string for ContactsManager.
FOUNDATION_EXPORT const unsigned char ContactsManagerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ContactsManager/PublicHeader.h>


